import joblib
import numpy as np
import pandas as pd

from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

X_train = joblib.load("X_train.pkl")
X_test = joblib.load("X_test.pkl")
y_train = joblib.load("y_train.pkl")
y_test = joblib.load("y_test.pkl")

print("X_train shape:", X_train.shape)
print("X_test shape:", X_test.shape)
print("y_train shape:", y_train.shape)
print("y_test shape:", y_test.shape)

model_knn = KNeighborsClassifier()
model_nb = GaussianNB()
model_svm = SVC()
model_dt = DecisionTreeClassifier(random_state=42)
model_rf = RandomForestClassifier(random_state=42)

models = {
    "KNN": model_knn,
    "NaiveBayes": model_nb,
    "SVM": model_svm,
    "DecisionTree": model_dt,
    "RandomForest": model_rf
}

print("Đã khởi tạo xong 5 mô hình.")

print("Training models...")
for name, model in models.items():
    model.fit(X_train, y_train)
    print(f"{name}: done")

print("Training completed!")

predictions = {}
for name, model in models.items():
    predictions[name] = model.predict(X_test)

print("Prediction completed!")
print("\nSample predictions (first 10):")
for name, y_pred in predictions.items():
    print(f"{name}: {y_pred[:10]}")

for name, y_pred in predictions.items():
    joblib.dump(y_pred, f"{name}_pred.pkl")

for name, model in models.items():
    joblib.dump(model, f"{name}_model.pkl")

print("Saved predictions and models successfully!")

print("\nModel Accuracy:")
accuracy_results = {}
for name, model in models.items():
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    accuracy_results[name] = acc
    print(f"{name}: {acc:.4f}")

results_df = pd.DataFrame({
    "Model": list(accuracy_results.keys()),
    "Accuracy": list(accuracy_results.values())
}).sort_values("Accuracy", ascending=False).reset_index(drop=True)

print(results_df)
